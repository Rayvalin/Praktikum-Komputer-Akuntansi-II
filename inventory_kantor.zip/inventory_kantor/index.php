<?php include 'config/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Inventory Kantor</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'pages/data_inventaris.php'; ?>
    <script src="assets/js/script.js"></script>
</body>
</html>