<h2>DATA INVENTARIS</h2>
<form method="GET">
    <label>Kategori</label>
    <select name="kategori">
        <option value="">---</option>
        <?php
        $res = $conn->query("SELECT * FROM kategori");
        while ($row = $res->fetch_assoc()) {
            echo "<option value='".$row['id_kategori']."'>".$row['nama_kategori']."</option>";
        }
        ?>
    </select>
    <button type="submit">Tampil</button>
</form>

<table border="1">
    <tr>
        <th>No</th><th>Kode Label</th><th>Nomor Seri</th><th>Nama Barang</th><th>Status</th><th>Lokasi</th><th>Tools</th>
    </tr>
    <?php
    $filter = isset($_GET['kategori']) && $_GET['kategori'] !== '' ? "WHERE kategori_id=".$_GET['kategori'] : "";
    $query = "SELECT i.*, l.nama_lokasi FROM inventaris i 
              LEFT JOIN lokasi l ON i.lokasi_id = l.id_lokasi $filter";
    $result = $conn->query($query);
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>$no</td>
            <td>{$row['kode_label']}</td>
            <td>{$row['nomor_seri']}</td>
            <td>{$row['nama_barang']}</td>
            <td>{$row['status']}</td>
            <td>{$row['nama_lokasi']}</td>
            <td>
                <a href='pages/pemeliharaan.php?id={$row['id']}'>Pemeliharaan</a> |
                <a href='pages/resume.php?id={$row['id']}'>Resume</a> |
                <a href='pages/edit_inventaris.php?id={$row['id']}'>Edit</a>
            </td>
        </tr>";
        $no++;
    }
    ?>
</table>