<?php
include '../config/db.php';
$id = $_GET['id'];
$data = $conn->query("SELECT * FROM inventaris WHERE id = $id")->fetch_assoc();
?>

<form method="POST" action="update_inventaris.php">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">
    Nama Barang: <input type="text" name="nama_barang" value="<?= $data['nama_barang'] ?>"><br>
    Status:
    <select name="status">
        <option value="Tersedia" <?= $data['status'] == 'Tersedia' ? 'selected' : '' ?>>Tersedia</option>
        <option value="Ditempatkan" <?= $data['status'] == 'Ditempatkan' ? 'selected' : '' ?>>Ditempatkan</option>
        <option value="Dipinjam" <?= $data['status'] == 'Dipinjam' ? 'selected' : '' ?>>Dipinjam</option>
    </select><br>
    <button type="submit">Update</button>
</form>