CREATE DATABASE inventory_kantor;
USE inventory_kantor;

CREATE TABLE kategori (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100) NOT NULL
);

CREATE TABLE lokasi (
    id_lokasi INT AUTO_INCREMENT PRIMARY KEY,
    nama_lokasi VARCHAR(100) NOT NULL
);

CREATE TABLE inventaris (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_label VARCHAR(20) NOT NULL,
    nomor_seri VARCHAR(50),
    nama_barang VARCHAR(100),
    status ENUM('Tersedia', 'Ditempatkan', 'Dipinjam'),
    lokasi_id INT,
    kategori_id INT,
    FOREIGN KEY (lokasi_id) REFERENCES lokasi(id_lokasi),
    FOREIGN KEY (kategori_id) REFERENCES kategori(id_kategori)
);